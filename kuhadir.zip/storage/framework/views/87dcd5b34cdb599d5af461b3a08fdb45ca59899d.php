
<?php $__env->startSection('title-page', 'Edit Guru'); ?>
<?php $__env->startSection('content'); ?>
<form action="/guru/update/<?php echo e($guru->id_guru); ?>" method="POST" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <div class="content">
      <div class="row">
        <div class="col-sm-6">
          <div class="row">
            <div class="col-sm-6">
              <div class="form-group">
                <label for="foto-guru">Profile Guru</label>
                <input type="file" name="foto_guru" id="foto-guru" value="<?php echo e($guru->foto_guru); ?>" placeholder="Profile Guru" class="form-control">
                <div class="text-danger">
                  <?php $__errorArgs = ['foto_guru'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
              </div>
            </div>
            <div class="col-sm-6">
              <img src="<?php echo e(url('image/'.$guru->foto_guru)); ?>"style="width: 150px;border-radius: 50%;" alt="Profile Guru">
            </div>
          </div>
          <div class="form-group">
            <label for="nip">NIP</label>
            <input type="number" name="nip_guru" id="nip" value="<?php echo e($guru->nip_guru); ?>" placeholder="NIP" class="form-control" readonly>
            <div class="text-danger">
              <?php $__errorArgs = ['nip_guru'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
          </div>
          <div class="form-group">
            <label for="nama-guru">Nama</label>
            <input type="text" name="nama_guru" id="nama-guru" value="<?php echo e($guru->nama_guru); ?>" placeholder="Nama" class="form-control">
            <div class="text-danger">
              <?php $__errorArgs = ['nama_guru'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
          </div>
          <div class="form-group">
            <label for="mapel">Mata Pelajaran</label>
            <input type="text" name="mapel" id="mapel" value="<?php echo e($guru->mapel); ?>" placeholder="Mata Pelajaran" class="form-control">
            <div class="text-danger">
              <?php $__errorArgs = ['mapel'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
          </div>
          <div class="form-group">
            <button class="btn btn-success btn-sm">Simpan</button>
          </div>
        </div>
      </div>
    </div>
  </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.dash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\framework\wp2\resources\views/edit-guru.blade.php ENDPATH**/ ?>