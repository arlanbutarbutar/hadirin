
<?php $__env->startSection('title-page', 'Siswa'); ?>
<?php $__env->startSection('content'); ?>
<div class="row">
  <div class="col-lg-1">
    <a href="/siswa/add" class="btn btn-primary btn-sm" style="margin-bottom: 20px;">Tambah</a><br>
  </div>
  <div class="col-lg-1">
    <a href="/siswa/print" target="_blank" class="btn btn-primary btn-sm" style="margin-bottom: 20px; margin-left: -20px;">Print to Printer</a>
  </div>
  <div class="col-lg-1">
    <a href="/siswa/printpdf" target="_blank" class="btn btn-success btn-sm" style="margin-bottom: 20px; margin-left: -7px;">Print to PDF</a>
  </div>
</div>
<?php if(session('message-success')): ?>
<div class="alert alert-success alert-dismissible" style="margin-bottom: 20px;">
  <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
  <h5><i class="icon fa fa-check"></i> <?php echo e((session('message-success'))); ?></h5>
</div>
<?php endif; ?>
<table class="table text-center table-bordered">
  <thead>
    <tr>
      <th>No</th>
      <th>NIS</th>
      <th>Nama Siswa</th>
      <th>Kelas</th>
      <th>Mata Pelajaran</th>
      <th colspan="3">Aksi</th>
    </tr>
  </thead>
  <tbody>
    <?php $__currentLoopData = $siswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <tr>
        <th><?php echo e($loop->iteration); ?></th>
        <td><?php echo e($data->nis); ?></td>
        <td><?php echo e($data->nama_siswa); ?></td>
        <td><?php echo e($data->kelas); ?></td>
        <td><?php echo e($data->mapel); ?></td>
        <td><a href="/siswa/edit/<?php echo e($data->id_siswa); ?>" class="btn btn-sm btn-warning">Ubah</a></td>
        <td>
          <button type="button" class="btn btn-danger" data-toggle="modal" data-target="#delete<?php echo e($data->id_siswa); ?>">Hapus</button>
          <div class="modal delete fade" id="delete<?php echo e($data->id_siswa); ?>">
            <div class="modal-dialog modal-sm">
              <div class="modal-content">
                <div class="modal-header border-bottom-0">
                  <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                  <h4 class="modal-title"></h4>
                </div>
                <div class="modal-body text-center">
                  <p>Anda yakin ingin menghapus guru <?php echo e($data->nama_siswa); ?>?</p>
                </div>
                <div class="modal-footer border-top-0">
                  <a href="/siswa/delete/<?php echo e($data->id_siswa); ?>" class="btn btn-danger">Hapus</a>
                </div>
              </div>
            </div>
          </div>
        </td>
      </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </tbody>
</table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\framework\wp2\resources\views/siswa.blade.php ENDPATH**/ ?>