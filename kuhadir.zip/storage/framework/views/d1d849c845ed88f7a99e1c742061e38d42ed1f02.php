<!doctype html>
<html lang="en">
  <head>
    <?php echo $__env->make('partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  </head>
  <body>
    <div class="container-fluid">
      <div class="row justify-content-center mt-5">
        <div class="col-md-10">
          <div class="card shadow border-light text-center" data-title="hello" data-intro="Hai guys!!">
            <div class="card-header">
              <nav class="navbar navbar-light bg-light">
                <div class="container-fluid">
                  <h3 class="navbar-brand font-weight-bold"><img src="img/hand.png" class="animate__animated animate__wobble hello" style="width: 50px; z-index: 2;" alt="hand"> Hadirin</h3>
                  <div>
                    <h5 class="card-title">Hai <?php echo e(Auth::user()->name); ?> !</h5>
                    <a href="/console" class="btn btn-outline-success btn-sm shadow"><i class="fas fa-angle-left"></i> Back</a>
                  </div>
                </div>
              </nav>
            </div>
            <div class="card-body">
              <?php if(session()->has('success')): ?>
              <div class="alert alert-success alert-dismissible fade show" role="alert">
                <?php echo e(session('success')); ?>

                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
              </div>
              <?php endif; ?>
              <div class="table-responsive">
                <table class="table">
                  <thead>
                    <tr>
                      <th scope="col">#</th>
                      <th scope="col">Kelas</th>
                      <th scope="col">Status</th>
                      <th scope="col">Tgl Absen</th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php $__currentLoopData = $absen; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <tr>
                        <th scope="row"><?php echo e($loop->iteration); ?></th>
                        <td><?php echo e($row->name_class); ?></td>
                        <td><?php echo e($row->status_absen); ?></td>
                        <td><?php echo e($row->tgl_absen); ?></td>
                      </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <?php echo $__env->make('partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  </body>
</html><?php /**PATH D:\xampp\htdocs\framework\kuhadir\resources\views/console/kelas.blade.php ENDPATH**/ ?>