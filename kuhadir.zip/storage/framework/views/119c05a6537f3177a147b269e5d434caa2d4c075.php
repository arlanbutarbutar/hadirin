<?php $__env->startSection('title-page', 'Home'); ?>
<?php $__env->startSection('content'); ?>
  
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\framework\wp2\resources\views/home.blade.php ENDPATH**/ ?>