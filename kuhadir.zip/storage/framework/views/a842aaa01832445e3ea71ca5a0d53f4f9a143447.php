
<?php $__env->startSection('content'); ?>
<div class="card-body">
  <h5 class="card-title">Edit Role Pengguna!</h5>
  <div class="col-4 m-auto mt-3">
    <form action="/console/update/<?php echo e($user->id); ?>" method="POST">
      <?php echo csrf_field(); ?>
      <div class="form-group">
        <label for="role">Role</label>
        <select name="id_role" id="role" class="form-control">
          <option>Pilih Role</option>
          <?php $__currentLoopData = $role; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rowRole): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <option value="<?php echo e($rowRole->id_role); ?>"><?php echo e($rowRole->role); ?></option>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
      </div>
      <div class="form-group">
        <button type="submit" class="btn btn-warning btn-sm shadow mt-3">Ubah</button>
      </div>
    </form>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('partials.dash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\framework\kuhadir\resources\views/console/user-edit.blade.php ENDPATH**/ ?>