
<?php $__env->startSection('title-page', 'Detail Guru'); ?>
<?php $__env->startSection('content'); ?>
<table class="table">
  <tr>
    <th width="100px">NIP</th>
    <th width="10px">:</th>
    <td><?php echo e($guru->nip_guru); ?></td>
  </tr>
  <tr>
    <th width="100px">Nama Guru</th>
    <th width="10px">:</th>
    <td><?php echo e($guru->nama_guru); ?></td>
  </tr>
  <tr>
    <th width="100px">Mata Pelajaran</th>
    <th width="10px">:</th>
    <td><?php echo e($guru->mapel); ?></td>
  </tr>
  <tr>
    <th width="100px">Profile Guru</th>
    <th width="10px">:</th>
    <td><img src="<?php echo e(url('image/'.$guru->foto_guru)); ?>"style="width: 100px;border-radius: 50%;" alt="Profile Guru"></td>
  </tr>
  <tr>
    <th>
      <a href="/guru" class="btn btn-success btn-sm">Kembali</a>
    </th>
  </tr>
</table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.dash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\framework\wp2\resources\views/detail-guru.blade.php ENDPATH**/ ?>