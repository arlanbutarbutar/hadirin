
<?php $__env->startSection('title-page', 'Edit Siswa'); ?>
<?php $__env->startSection('content'); ?>
<form action="/siswa/update/<?php echo e($siswa->id_siswa); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <div class="content">
      <div class="row">
        <div class="col-sm-6">
          <div class="form-group">
            <label for="nis">NIS</label>
            <input type="number" name="nis" id="nis" value="<?php echo e($siswa->nis); ?>" placeholder="NIS" class="form-control">
            <div class="text-danger">
              <?php $__errorArgs = ['nis'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
          </div>
          <div class="form-group">
            <label for="nama-siswa">Nama</label>
            <input type="text" name="nama_siswa" id="nama-siswa" value="<?php echo e($siswa->nama_siswa); ?>" placeholder="Nama" class="form-control">
            <div class="text-danger">
              <?php $__errorArgs = ['nama_siswa'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
          </div>
          <div class="form-group">
            <label for="kelas">Kelas</label>
            <select name="kelas" id="kelas" value="<?php echo e(old('kelas')); ?>" class="form-control">
              <?php $__currentLoopData = $kelas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rowKelas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <option value="<?php echo e($rowKelas->id_kelas); ?>"><?php echo e($rowKelas->kelas); ?></option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <div class="text-danger">
              <?php $__errorArgs = ['kelas'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
          </div>
          <div class="form-group">
            <label for="mapel">Mata Pelajaran</label>
            <select name="mapel" id="mapel" value="<?php echo e(old('mapel')); ?>" class="form-control">
              <?php $__currentLoopData = $mapel; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rowMapel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <option value="<?php echo e($rowMapel->id_mapel); ?>"><?php echo e($rowMapel->mapel); ?></option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <div class="text-danger">
              <?php $__errorArgs = ['mapel'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e($message); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
          </div>
          <div class="form-group">
            <button class="btn btn-success btn-sm">Simpan</button>
          </div>
        </div>
      </div>
    </div>
  </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.dash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\framework\wp2\resources\views/edit-siswa.blade.php ENDPATH**/ ?>