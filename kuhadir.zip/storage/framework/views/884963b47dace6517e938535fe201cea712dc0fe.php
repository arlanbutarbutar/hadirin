<!doctype html>
<html lang="en">
  <head>
    <?php echo $__env->make('partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  </head>
  <body>
    <div class="container-fluid">
      <div class="row justify-content-center mt-5">
        <div class="col-md-4">
          <div class="card shadow border-light text-center" data-title="hello" data-intro="Hai guys!!">
            <div class="card-header">
              <h3 class="navbar-brand font-weight-bold"><img src="img/hand.png" class="animate__animated animate__wobble hello" style="width: 50px; z-index: 2;" alt="hand"> Hadirin</h3>
            </div>
            <div class="card-body">
              <?php if(session()->has('success')): ?>
              <div class="alert alert-success alert-dismissible fade show" role="alert">
                <?php echo e(session('success')); ?>

                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
              </div>
              <?php endif; ?>
              <form action="/absen" method="POST">
                <?php echo csrf_field(); ?>
                <h3>Kelas WP 2</h3>
                <div class="form-group mb-3">
                  <label for="absen">Status Absen</label>
                  <select name="id_status_absen" id="absen" class="form-control <?php $__errorArgs = ['id_status_absen'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                    <option selected>Pilih Status</option>
                    <?php $__currentLoopData = $status; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rowS): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <option value="<?php echo e($rowS->id_status_absen); ?>"><?php echo e($rowS->status_absen); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select>
                </div>
                <div class="form-group">
                  <button type="submit" class="btn btn-success btn-sm shadow">Absen</button>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
    <?php echo $__env->make('partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  </body>
</html><?php /**PATH D:\xampp\htdocs\framework\kuhadir\resources\views/console/absen.blade.php ENDPATH**/ ?>