<div class="card-header shadow border-bottom-0">
  <nav class="navbar navbar-light bg-light">
    <div class="container-fluid">
      <h3 class="navbar-brand font-weight-bold"><img src="<?php echo e(url('img/hand.png')); ?>" class="animate__animated animate__wobble hello" style="width: 50px; z-index: 2;" alt="hand"> Hai <?php echo e(Auth::user()->name); ?>! <br> this is
        <?php if(auth()->user()->id_role == 1): ?>
          your Dashboard
        <?php elseif(auth()->user()->id_role == 2): ?>
          Manage your class
        <?php else: ?>
          Your class
        <?php endif; ?>
      </h3>
      <div class="d-sm-flex justify-content-end">
        <?php if(auth()->user()->id_role == 2): ?>
        <button type="button" class="btn btn-success btn-sm shadow" data-bs-toggle="modal" data-bs-target="#addClass"><i class="fas fa-plus"></i> Add Class</button>
        <div class="modal fade" id="addClass" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header border-bottom-0">
                <h5 class="modal-title" id="exampleModalLabel">Add Class</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
              </div>
              <form action="/console/class/" method="POST">
                <?php echo csrf_field(); ?>
                <div class="modal-body">
                  <div class="form-group">
                    <label for="name">Nama kelas</label>
                    <input type="text" name="name_class" placeholder="Nama Kelas" class="form-control <?php $__errorArgs = ['name_class'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('name_class')); ?>" required>
                    <?php $__errorArgs = ['name_class'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  </div>
                  <div class="form-group mt-3">
                    <label for="class-type">Tipe Kelas</label>
                    <select name="id_class_type" id="class-type" class="form-control <?php $__errorArgs = ['id_class_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                      <option>Pilih Tipe Kelas</option>
                      <?php $__currentLoopData = $class_types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rowClass): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <option value="<?php echo e($rowClass->id_class_type); ?>"><?php echo e($rowClass->class_type); ?></option>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php $__errorArgs = ['id_class_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  </div>
                </div>
                <div class="modal-footer border-top-0 justify-content-center">
                  <button type="submit" class="btn btn-success btn-sm shadow">Add</button>
                </div>
              </form>
            </div>
          </div>
        </div>
        <?php endif; ?>
        <form action="<?php echo e(route('logout')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <button type="submit" class="btn btn-outline-danger btn-sm shadow" style="margin-left: 10px"><i class="fas fa-sign-out-alt"></i> Log Out</button>
        </form>
      </div>
    </div>
  </nav>
</div><?php /**PATH D:\xampp\htdocs\framework\kuhadir\resources\views/partials/head_dash.blade.php ENDPATH**/ ?>