<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css"/>
<title>Hadirin</title>
<style>.darkmode-toggle{z-index: 1;}</style>
<link rel="stylesheet" href="css/shepherd.css">
<link rel="stylesheet" href="css/scroll.css">
<link rel="stylesheet" href="/nodes_modules/shepherd.js/dist/css/shepherd-theme-dark.css">
<link rel="shortcut icon" href="img/hand.png">
<link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous"/><?php /**PATH D:\xampp\htdocs\framework\kuhadir\resources\views/partials/header.blade.php ENDPATH**/ ?>