<?php $__env->startSection('content'); ?>
<div class="card-body">
  <?php if(auth()->user()->id_role == 1): ?>
  <h2 class="card-title">Data Pengguna!</h2>
  <?php endif; ?>
  <?php if(session()->has('message-success')): ?>
  <div class="alert alert-success alert-dismissible fade show small" role="alert">
    <?php echo e(session('message-success')); ?>

    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
  </div>
  <?php endif; ?>
  <div class="table-responsive mt-5">
    <?php if(auth()->user()->id_role == 1): ?>
    <table class="table table-sm table-striped table-borderless">
      <thead>
        <tr>
          <th scope="col">#</th>
          <th scope="col">Nama</th>
          <th scope="col">Email</th>
          <th scope="col">Role</th>
          <th scope="col">Tgl Buat</th>
          <th colspan="2">Aksi</th>
        </tr>
      </thead>
      <tbody>
        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
          <th scope="row"><?php echo e($loop->iteration); ?></th>
          <td scope="row"><?php echo e($row->name); ?></td>
          <td scope="row"><?php echo e($row->email); ?></td>
          <td scope="row"><?php echo e($row->role); ?></td>
          <td scope="row"><?php echo e($row->date_created); ?></td>
          <td>
            <button type="button" class="btn btn-warning btn-sm shadow" data-bs-toggle="modal" data-bs-target="#edit<?php echo e($row->id); ?>"><i class="far fa-edit"></i> Edit</button>
            <div class="modal fade" id="edit<?php echo e($row->id); ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
              <div class="modal-dialog">
                <div class="modal-content">
                  <div class="modal-header border-bottom-0">
                    <h5 class="modal-title" id="exampleModalLabel">Ubah Role Pengguna</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                  </div>
                  <form action="/console/edit/<?php echo e($row->id); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="modal-body text-center">
                      <div class="form-group">
                        <select name="id_role" id="role" class="form-control">
                          <option>Pilih Role</option>
                          <?php $__currentLoopData = $role; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rowRole): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <option value="<?php echo e($rowRole->id_role); ?>"><?php echo e($rowRole->role); ?></option>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                      </div>
                    </div>
                    <div class="modal-footer border-top-0 justify-content-center">
                      <button type="submit" class="btn btn-warning btn-sm shadow">Edit</button>
                    </div>
                  </form>
                </div>
              </div>
            </div>
          </td>
          <td>
            <button type="button" class="btn btn-danger btn-sm shadow" data-bs-toggle="modal" data-bs-target="#delete<?php echo e($row->id); ?>"><i class="fas fa-trash"></i> Delete</button>
            <div class="modal fade" id="delete<?php echo e($row->id); ?>">
              <div class="modal-dialog">
                <div class="modal-content">
                  <div class="modal-header border-bottom-0">
                    <h5 class="modal-title" id="exampleModalLabel"></h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                  </div>
                  <div class="modal-body text-center">
                    <p>Anda yakin ingin menghapus <?php echo e($row->role." ".$row->name); ?>?</p>
                  </div>
                  <div class="modal-footer border-top-0 justify-content-center">
                    <a href="/console/delete/<?php echo e($row->id); ?>" class="btn btn-danger btn-sm shadow"> Delete</a>
                  </div>
                </div>
              </div>
            </div>
          </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>
    </table>
    <?php elseif(auth()->user()->id_role == 2): ?>
    <table class="table table-sm table-striped table-borderless">
      <thead>
        <tr>
          <th scope="col">#</th>
          <th scope="col">Nama Kelas</th>
          <th scope="col">Kode Kelas</th>
          <th scope="col">Tipe Kelas</th>
          <th scope="col">Tgl Buat</th>
          <th colspan="3">Aksi</th>
        </tr>
      </thead>
      <tbody>
        <?php $__currentLoopData = $classes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
          <th scope="row"><?php echo e($loop->iteration); ?></th>
          <td scope="row"><?php echo e($row->name_class); ?></td>
          <td scope="row" class="d-flex justify-content-center">
            <input type="text" value="<?php echo e($row->class_code); ?>" readonly id="pilih" class="bg-transparent border-0" style="width: 60px; outline: none;">
            <div><span class="badge bg-success text-white" style="cursor:pointer; margin-left: 5px" onclick="copy_text()"><i class="far fa-copy"></i></span></div>
          </td>
          <td scope="row"><?php echo e($row->class_type); ?></td>
          <td scope="row"><?php echo e($row->date_created); ?></td>
          <td>
            <button type="button" class="btn btn-success btn-sm shadow" data-bs-toggle="modal" data-bs-target="#detail<?php echo e($row->id_class); ?>"><i class="far fa-eye"></i> Detail</button>
            <div class="modal fade" id="detail<?php echo e($row->id_class); ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
              <div class="modal-dialog modal-lg">
                <div class="modal-content">
                  <div class="modal-header border-bottom-0">
                    <h5 class="modal-title" id="exampleModalLabel">Daftar kehadiran</h5>
                    <div class="d-flex">
                      <a href="/console/class-print" target="_blank" class="btn btn-outline-primary btn-sm shadow"><i class="fas fa-print"></i> Print to Printer</a>
                      <a href="/console/class-printpdf" target="_blank" class="btn btn-outline-success btn-sm shadow" style="margin-left: 10px;"><i class="fas fa-print"></i> Print to PDF</a>
                      <button type="button" class="btn-close" style="margin-top: 0px; margin-left: 10px;" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                  </div>
                  <div class="modal-body text-center">
                    <table class="table table-sm table-borderless table-striped">
                      <thead>
                        <tr>
                          <th scope="col">#</th>
                          <th scope="col">NIM</th>
                          <th scope="col">Nama Pelajar</th>
                          <th scope="col">Kelas</th>
                          <th scope="col">Status</th>
                          <th scope="col">Tgl Absen</th>
                        </tr>
                      </thead>
                      <tbody>
                        <?php $__currentLoopData = $absen; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                          <th scope="row"><?php echo e($loop->iteration); ?></th>
                          <td><?php echo e($row->number); ?></td>
                          <td><?php echo e($row->name); ?></td>
                          <td><?php echo e($row->name_class); ?></td>
                          <td><?php echo e($row->status_absen); ?></td>
                          <td><?php echo e($row->tgl_absen); ?></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
          </td>
          <td>
            <button type="button" class="btn btn-warning btn-sm shadow" data-bs-toggle="modal" data-bs-target="#edit<?php echo e($row->id_class); ?>"><i class="far fa-edit"></i> Edit</button>
            <div class="modal fade" id="edit<?php echo e($row->id_class); ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
              <div class="modal-dialog">
                <div class="modal-content">
                  <div class="modal-header border-bottom-0">
                    <h5 class="modal-title" id="exampleModalLabel">Ubah Data kelas</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                  </div>
                  <form action="/console/edit-class/<?php echo e($row->id_class); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="modal-body text-center">
                      <div class="form-group">
                        <label for="name">Nama kelas</label>
                        <input type="text" name="name_class" placeholder="Nama Kelas" class="form-control <?php $__errorArgs = ['name_class'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e($row->name_class); ?>" required>
                        <?php $__errorArgs = ['name_class'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                      </div>
                      <div class="form-group mt-3">
                        <label for="class-type">Tipe Kelas</label>
                        <select name="id_class_type" id="class-type" class="form-control <?php $__errorArgs = ['id_class_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                          <option>Pilih Tipe Kelas</option>
                          <?php $__currentLoopData = $class_types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rowClass): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <option value="<?php echo e($rowClass->id_class_type); ?>"><?php echo e($rowClass->class_type); ?></option>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php $__errorArgs = ['id_class_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                      </div>
                    </div>
                    <div class="modal-footer border-top-0 justify-content-center">
                      <button type="submit" class="btn btn-warning btn-sm shadow">Edit</button>
                    </div>
                  </form>
                </div>
              </div>
            </div>
          </td>
          <td>
            <button type="button" class="btn btn-danger btn-sm shadow" data-bs-toggle="modal" data-bs-target="#delete<?php echo e($row->id_class); ?>"><i class="fas fa-trash"></i> Delete</button>
            <div class="modal fade" id="delete<?php echo e($row->id_class); ?>">
              <div class="modal-dialog">
                <div class="modal-content">
                  <div class="modal-header border-bottom-0">
                    <h5 class="modal-title" id="exampleModalLabel"></h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                  </div>
                  <div class="modal-body text-center">
                    <p>Anda yakin ingin menghapus kelas <?php echo e($row->name_class); ?>?</p>
                  </div>
                  <div class="modal-footer border-top-0 justify-content-center">
                    <a href="/console/delete-class/<?php echo e($row->id_class); ?>" class="btn btn-danger btn-sm shadow"> Delete</a>
                  </div>
                </div>
              </div>
            </div>
          </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>
    </table>
    <?php elseif(auth()->user()->id_role == 3): ?>
    <p>Lihat kehadiran kamu di kelas</p>
    <a href="/class" class="btn btn-success btn-sm shadow"><i class="fas fa-book-reader"></i> Kelas</a>
    <?php endif; ?>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('partials.dash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\framework\kuhadir\resources\views/console/dash.blade.php ENDPATH**/ ?>