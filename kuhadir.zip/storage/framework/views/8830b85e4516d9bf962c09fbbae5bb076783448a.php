<!doctype html>
<html lang="en">
  <head>
    <?php echo $__env->make('partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  </head>
  <body>
    <div class="container-fluid">
      <div class="row justify-content-center mt-5">
        <div class="col-md-10">
          <div class="card shadow border-0 text-center" data-title="hello" data-intro="Hai guys!!">
            <?php echo $__env->make('partials.head_dash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="card-body">
              <h5 class="card-title">Detail Data Pengguna!</h5>
              <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rowUser): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <div class="card border-0">
                <div class="card-header">
                  
                </div>
                <div class="card-body">
                  <blockquote class="blockquote mb-0">
                    <?php $__currentLoopData = $classes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rowClass): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <p><?php echo e($rowClass->name_class); ?></p>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <footer class="blockquote-footer">Someone famous in <cite title="Source Title">Source Title</cite></footer>
                  </blockquote>
                </div>
              </div>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
          </div>
        </div>
      </div>
    </div>
    <?php echo $__env->make('partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  </body>
</html><?php /**PATH D:\xampp\htdocs\framework\kuhadir\resources\views/console/vu.blade.php ENDPATH**/ ?>