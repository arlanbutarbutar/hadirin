<!-- Sidebar user panel -->
<div class="user-panel">
  <div class="pull-left image">
    <img src="<?php echo e(asset('template')); ?>/dist/img/user2-160x160.png" class="img-circle" alt="User Image">
  </div>
  <div class="pull-left info">
    <p><?php echo e(Auth::user()->name); ?></p>
    <a href="#"><i class="fa fa-circle text-success"></i>
      <?php if(auth()->user()->role == 1): ?>
        Administrator
      <?php elseif(auth()->user()->role == 2): ?>
        Siswa
      <?php endif; ?>
    </a>
  </div>
</div>
<!-- sidebar menu: : style can be found in sidebar.less -->

<ul class="sidebar-menu" data-widget="tree">
  <li class="<?php echo e(request()->is('/') ? 'active' : ''); ?>"><a href="/"><i class="fa fa-dashboard"></i> <span>Home</span></a></li>
  <?php if(auth()->user()->role == 1): ?>
    <li class="<?php echo e(request()->is('guru') ? 'active' : ''); ?>"><a href="/guru"><i class="fa fa-book"></i> <span>Guru</span></a></li>
    <li class="<?php echo e(request()->is('siswa') ? 'active' : ''); ?>"><a href="/siswa"><i class="fa fa-book"></i> <span>Siswa</span></a></li>
  <?php elseif(auth()->user()->role == 2): ?>
    <li class="<?php echo e(request()->is('user') ? 'active' : ''); ?>"><a href="/user"><i class="fa fa-book"></i> <span>Siswa</span></a></li>
  <?php endif; ?>
</ul><?php /**PATH D:\xampp\htdocs\framework\wp2\resources\views/layouts/sidebar.blade.php ENDPATH**/ ?>